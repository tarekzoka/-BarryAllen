# -*- coding: utf-8 -*-
#
# Barry Allen by gutemine
#
# Plugin wrapper to speed up Startup
#
import os
from Plugins.Plugin import PluginDescriptor
from Components.config import config
if os.path.exists("/var/lib/dpkg/status") and os.path.exists("/media/ba/BarryAllen/UserScripts.py"):
	import UserScripts
if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/GoldenPanel/plugin.pyo"):
	os.remove("/usr/lib/enigma2/python/Plugins/Extensions/GoldenPanel/plugin.pyo")
if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/GoldenPanel/plugin.py"):
	os.remove("/usr/lib/enigma2/python/Plugins/Extensions/GoldenPanel/plugin.py")
if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/GoldenFeed/plugin.pyo"):
	os.remove("/usr/lib/enigma2/python/Plugins/Extensions/GoldenFeed/plugin.pyo")
if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/GoldenFeed/plugin.py"):
	os.remove("/usr/lib/enigma2/python/Plugins/Extensions/GoldenFeed/plugin.py")
if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/PersianDreambox/plugin.py"):
	os.remove("/usr/lib/enigma2/python/Plugins/Extensions/PersianDreambox/plugin.py")
if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/PersianDreambox/plugin.pyo"):
	os.remove("/usr/lib/enigma2/python/Plugins/Extensions/PersianDreambox/plugin.pyo")
if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatDownloader/plugin.pyo"):
	os.remove("/usr/lib/enigma2/python/Plugins/Extensions/DreamOSatDownloader/plugin.pyo")

import gettext
barryallen_path = "/media/ba"
barryallen_plugindir="/usr/lib/enigma2/python/Plugins/Extensions/BarryAllen" 
barryallen_localedir="%s/locale" % barryallen_path
REDC =  '\033[31m'                                                           
ENDC = '\033[m'                                   
                                           
def cprint(text):                   
        print REDC+text+ENDC  

# add local language file            
ba_sp=config.osd.language.value.split("_")
ba_language = ba_sp[0]         
if os.path.exists("%s/%s" % (barryallen_localedir, ba_language)) == True:
   os.environ["LANGUAGE"] = ba_sp[1]
else:
   os.environ['LANGUAGE']='en'
   ba_language='en'
if ba_language == 'ar':
   ar="                                                                           "
   ar2=""
else:
   ar=""
   ar2=""
if os.path.exists("/media/ba/locale"):
   _=gettext.Catalog('barryallen', '/media/ba/locale', ba_sp).gettext

def main(session,**kwargs):
	if not os.path.exists("/media/ba/BarryAllen/BarryAllen.py"):
		if os.path.exists("/usr/lib/enigma2/python/Plugins/Bp"):
			cprint(" [BARRYALLEN] checking for /media mount !")
			os.system("umount /media")
	if os.path.exists("/media/ba/BarryAllen/BarryAllen.py"):
		if not os.path.exists(barryallen_plugindir):
			os.sysmlink("/media/ba/BarryAllen/BarryAllen.py", barryallen_plugindir)
		if os.path.exists(barryallen_plugindir):
			from Plugins.Extensions.BarryAllen.BarryAllen import BarryAllenMain
			session.open(BarryAllenMain)
		else:
			cprint(" [BARRYALLEN] Plugin not found, sorry!")
	else:
		cprint("[BARRYALLEN] Plugin not found, sorry!")

def autostart(reason, **kwargs):                                               
	if kwargs.has_key("session") and reason == 0:                               
		cprint("[BARRYALLEN] autostart")
	        session = kwargs["session"]                                             
		if os.path.exists("/media/ba/.baprotect") and os.path.exists("/.bainfo") and os.path.exists("/dev/mmcblk0"):
				os.remove("/dev/mmcblk0")
				os.symlink("/dev/null","/dev/mmcblk0")
		if os.path.exists("/etc/init.d/umountfs"):
			b=open("/etc/init.d/umountfs","r")
			inhalt=b.read()
			b.close()
			if inhalt.find("sync") is -1:       
				cprint("[BARRYALLEN] patching umountfs")
				inhalt=inhalt.replace(": exit 0","sync\n: exit 0")
				b=open("/etc/init.d/umountfs","w")
				b.write(inhalt)
				b.close()
		if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/GoldenPanel/plugin.pyo"):
			os.remove("/usr/lib/enigma2/python/Plugins/Extensions/GoldenPanel/plugin.pyo")
		if not os.path.exists("/media/ba/BarryAllen/BarryAllen.py"):
			if os.path.exists("/usr/lib/enigma2/python/Plugins/Bp"):
				cprint(" [BARRYALLEN] checking for /media mount !")
				os.system("umount /media")
		if os.path.exists("/var/lib/dpkg/status") and os.path.exists("/media/ba/BarryAllen/UserScripts.py"):
			cprint("[BARRYALLEN] UserScript autostart")
			# add UserSscripts auto start ...
	        	session.open(UserScripts.UserScriptsStartup)       
		else:
			cprint("[BARRYALLEN] UserScript NO autostart")

def sessionstart(reason, **kwargs):                                               
        if reason == 0 and "session" in kwargs:                                                        
		if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/GoldenPanel/plugin.pyo"):
			os.remove("/usr/lib/enigma2/python/Plugins/Extensions/GoldenPanel/plugin.pyo")
		if os.path.exists("/usr/lib/enigma2/python/Plugins/Extensions/WebInterface/WebChilds/Toplevel.py"):
			if os.path.exists("/media/ba/BarryAllen/BarryAllen.py"):
				if not os.path.exists(barryallen_plugindir):
					os.sysmlink("/media/ba/BarryAllen/BarryAllen.py", barryallen_plugindir)
                        	from Plugins.Extensions.WebInterface.WebChilds.Toplevel import addExternalChild
		        	from Plugins.Extensions.BarryAllen.BarryAllen import BarryAllen
                        	addExternalChild( ("barryallen", BarryAllen(), "Barry Allen", "1", True) )          
                else:                                                                                  
			cprint("[BARRYALLEN] Webif not found")

def Plugins(**kwargs):
	if os.path.exists("%s/BarryAllen.py" % barryallen_plugindir):
		return [PluginDescriptor(name="Barry Allen", description=ar+_("the second Flash"), where = PluginDescriptor.WHERE_PLUGINMENU, icon="barryallen.png", fnc=main),
			PluginDescriptor(name="Barry Allen", description=ar+_("the second Flash"), where = PluginDescriptor.WHERE_EXTENSIONSMENU, icon="g3icon_ba.png", fnc=main),
            		PluginDescriptor(where=PluginDescriptor.WHERE_SESSIONSTART, fnc=sessionstart, needsRestart=False),
            		PluginDescriptor(where=[PluginDescriptor.WHERE_SESSIONSTART, PluginDescriptor.WHERE_AUTOSTART], fnc=autostart)]
	else:
		cprint("[BARRYALLEN] Plugin not found")
